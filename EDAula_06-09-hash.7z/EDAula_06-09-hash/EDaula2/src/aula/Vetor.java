package aula;

import java.util.Arrays;

import javax.swing.JOptionPane;

public class Vetor {
	private int vetor[];
	private int tamanho;
	
	Vetor(){
		tamanho = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor: "));
		vetor = new int[tamanho];
	}
	
	// Função alterada na Aula HASH 06/09
	public void preencherVetor() {
		// Transformar o preencher vetor em uma função hash
		// utilizar % como mod para simbolizar a sobra da divisao de num pelo vetor
		int i;
		for(i =0; i < tamanho; i++) {
			int aux = Integer.parseInt(JOptionPane.showInputDialog("Digite o número do índice " + i + ":"));
			vetor [aux % tamanho] = aux;
		//formula que o Juliano criou que cria um aux para dividir com o tamanho do vetor
			
		}
	}
	
	
	/*public void colisaoVetor() {
		int i;
		for(i =0; i < tamanho; i++) {
			int aux = Integer.parseInt(JOptionPane.showInputDialog("Digite o número do índice " + i + ":"));
			while (aux != 0) {
			int indice = aux % tamanho;
			while vetor[indice] !0 
			vetor [aux % tamanho] = aux;
		//formula que o Juliano criou que cria um aux para dividir com o tamanho do vetor
			
		}
	}
	
	 fc = n/m
	 Onde: n é a quantidade de elementos e m quantidade de posições
	 Se ( fc <=1 ) menor chance de colisão | Se (fc > 1) alta chance
	 Ex: 10 elementos em 100 posições -> fc = 0,1
	 100 elementos em 10 posições -> fc = 10 */
	
	public void imprimirVetor() {
		for (int i = 0; i < tamanho; i++) {
			JOptionPane.showMessageDialog(null, vetor[i]);
		}
	}
	
	public int[] getVetor() {
		return vetor;
	}
	
	@Override
	public String toString() {
		return "Vetor [vetor=" + Arrays.toString(vetor) + "]";
	}

	
	

}


