//package aula;

//public class BuscaBinaria {

				//boolean achou = false;

//}
